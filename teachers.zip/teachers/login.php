<?php include('server.php') ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login to Movie App</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <section>
    <div class="box">
      <div class="square"></div>
      <div class="square"></div>
      <div class="square"></div>
      <div class="square"></div>
      <div class="square"></div>
      <div class="square"></div>
      <div class="container">
        <div class="form">
          <h2>LOGIN As Teacher</h2>
          <form id="loginForm" method="post" action="login.php">
            <?php include('errors.php'); ?>
            <div class="message"><?php if(isset($message)) { echo $message; } ?></div>
            <div class="inputBx">
              <input type="text" id="username" name="username" required />
              <span>Username</span>
              <i class="fas fa-user"></i>
            </div>
            <div class="inputBx password">
              <input type="password" id="password" name="password" required />
              <span>Password</span>
              <a href="#" class="password-control" onclick="togglePasswordVisibility()">
              </a>
              <i class="fas fa-key"></i>
            </div>
            <div class="inputBx">
              <button type="submit" value="Log in" name="login_user">Log in</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </section>

  <script>
    let passwordVisible = false;

    function togglePasswordVisibility() {
      const passwordInput = document.getElementById('password');
      const toggleIcon = document.getElementById('toggleIcon');
      passwordVisible = !passwordVisible;
      passwordInput.type = passwordVisible ? 'text' : 'password';
      toggleIcon.className = passwordVisible ? 'fas fa-eye-slash' : 'fas fa-eye';
    }
  </script>
</body>
</html>
