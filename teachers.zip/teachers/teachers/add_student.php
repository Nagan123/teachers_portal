<?php 
session_start(); 

if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location:../login.php');
    exit();
}

if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['username']);
    header("location: login.php");
    exit();
}

require_once 'connection.php';

if ($_SERVER['REQUEST_METHOD'] === "POST") {
    $username = mysqli_real_escape_string($connection, $_POST['username']);
    $subject = mysqli_real_escape_string($connection, $_POST['subject']);
    $marks = mysqli_real_escape_string($connection, $_POST['marks']);
    $date = date('Y-m-d');

    // Capitalize the first letter of each word in username and subject
    $username = ucwords(strtolower($username));
    $subject = ucwords(strtolower($subject));

    // Check if the record already exists
    $checkQuery = "SELECT * FROM students WHERE name='$username' AND subject='$subject'";
    $checkResult = mysqli_query($connection, $checkQuery);
    
    if (mysqli_num_rows($checkResult) > 0) {
        // Record exists
        echo "<script>alert('Record with the same student name and subject already exists.');window.location='index.php'; </script>";
    } else {
        // Insert new record
        $sql = "INSERT INTO students (name, subject, marks, created_at) VALUES ('$username', '$subject', '$marks', '$date')";
        $result = mysqli_query($connection, $sql);

        if (!$result) {
            echo "<script>alert('Record not inserted.');window.location='index.php'; </script>";
        } else {
            echo "<script>alert('Record inserted successfully.');window.location='index.php'; </script>";
        }
    }
}
?>
