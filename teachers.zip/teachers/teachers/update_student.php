<?php 
	session_start(); 

	if (!isset($_SESSION['username'])) {
		$_SESSION['msg'] = "You must log in first";
		header('location:../login.php');
	}

	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header("location: login.php");
	}

require_once 'connection.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    $id = $_POST['id'];
    $username = $_POST['username'];
    $subject = $_POST['subject'];
    $marks = $_POST['marks'];

    $query = "UPDATE students SET name='$username', subject='$subject', marks='$marks' WHERE id='$id'";
    $result = mysqli_query($connection, $query);

			if(!$result)
			{
				 echo "<script>alert('Record not inserted.');window.location='index.php'; </script>";
			}
					
			else {
			   echo "<script>alert('Record inserted successfully.');window.location='index.php'; </script>";
				
			}
			}

?>
