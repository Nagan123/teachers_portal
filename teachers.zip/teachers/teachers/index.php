<?php 
	session_start(); 

	if (!isset($_SESSION['username'])) {
		$_SESSION['msg'] = "You must log in first";
		header('location:../login.php');
	}

	if (isset($_GET['logout'])) {
		session_destroy();
		unset($_SESSION['username']);
		header("location: ../login.php");
	}

?>
<?php
	include 'connection.php';
	$tableName = "students";
	$count = 1;
	if (isset($_GET['delids'])) 
	{
	    $ids = trim($_GET['delids']);
	    $sql = "DELETE FROM $tableName WHERE id = '$ids'";
	    $querys = mysqli_query($connection,$sql);
	    if ($querys == 1) 
	    {
	        $msg = "Data Successfully deleted";
	    } 
	    else 
	    {
	        $msg = "Unable to delete";
	    }
	}
	//$ids = trim($_GET['id']);
	
?>
<html lang="zxx" class="js">
   <head>
      <base href="" />
      <meta charset="utf-8" />
      <meta name="author" content="chesa" />
      <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
      <meta name="description" content="" />
      <!-- Fav Icon  -->
      <link rel="shortcut icon" href="asstets/images/logo.jpg" />
      <!-- Page Title  -->
      <title>Teachers Portal</title>
      <!-- StyleSheets  -->
      <link rel="stylesheet" href="assets/css/dashlite.css?ver=2.4.0" />
      <link id="skin-default" rel="stylesheet" href="assets/css/theme.css?ver=2.4.0" />
      <script src="https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js"></script>
      <style>
         .tooltip-wrap {
         position: relative;
         }
         .tooltip-wrap .tooltip-content {
         /*bottom: 85%;*/
         left: 5%;
         right: 5%;
         visibility: hidden;
         width: max-content;
         background-color: #fff;
         color: #fff;
         text-align: center;
         border-radius: 6px;
         padding: 5px;
         /* Position the tooltip */
         position: absolute;
         z-index: 1;
         }
         .tooltip-wrap:hover .tooltip-content {
         visibility: visible;
         }
         @media (max-width: 767px) {
         .hidden-mobile {
         display: none;
         }
         }
         @media only screen and (min-width: 960px) {
         .hidedesktop {
         display: none;
         }
         }
         /* Style for path container */
         .path {
         display: flex;
         align-items: center;
         position: relative;
         right: 9;
         }
         /* Style for path item */
         .path-item {
         margin-right: 10px;
         white-space: nowrap;
         font-size: 11px;
         text-transform: uppercase;
         letter-spacing: 0.05rem;
         }
         /* Style for the last path item */
         .path-item:last-child {
         font-weight: bold; /* Optional: make the last item bold */
         color: #ffa348;
         }
      </style>
   </head>
   <body class="nk-body bg-lighter npc-general has-sidebar">
      <div class="nk-app-root">
         <div class="nk-main">
            <?php include('sidebar.php');?>
            <div class="nk-wrap">
               <?php include('header.php');?>
               <div class="nk-content">
                  <div class="container-fluid">
                     <div class="nk-content-inner">
                        <div class="nk-content-body">
                           <div class="nk-block-head nk-block-head-sm">
                              <div class="nk-block-between">
                                 <div class="nk-block-head-content">
                                    <a href="#" class="btn btn-primary" data-toggle="modal" data-target="#add"><em class="icon ni ni-edit"></em><span> Add Students</span></a>
									
									
									
									<div class="modal fade" id="add" role="dialog" aria-labelledby="uploadModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                   <div class="modal-content">
                                                      <div class="modal-header">
                                                         <h5 class="modal-title" id="uploadModalLabel">Add Student Details</h5>
                                                         <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                         <span aria-hidden="true">&times;</span>
                                                         </button>
                                                      </div>
                                                      <div class="modal-body">
                                                         <form autocomplete="off" action="add_student.php" method="post" enctype="multipart/form-data" role="form" class="form-validate is-alter">
                                                            <div class="col-md-12 form-group">
                                                               
															   <input type="hidden" class="form-control" value="<?php echo $id; ?>" name="id" required>
                                                               
																<div class="form-control-wrap">
																<label class="form-label" for="fva-username">Username</label>
																	<input type="text" class="form-control" name="username" required>
																</div>
																
																
																<div class="form-control-wrap">
																<label class="form-label mt-2" for="fva-subject">Subject</label>
																	<input type="text" class="form-control" name="subject" required>
																</div>
																
																
																<div class="form-control-wrap">
																<label class="form-label mt-2" for="fva-marks">Marks</label>
																	<input type="number" class="form-control" name="marks" required>
																</div>
																
                                                            </div>
                                                            <br/>
                                                            <div class="col-md-12">
                                                               <button type="submit" name="los" value="Covert Lead" class="btn btn-primary btn-md btn-block mr-1 mb-2" style="width:150px"><em class="icon ni ni-plus"></em> Submit</button>
                                                            </div>
                                                         </form>
                                                      </div>
                                                   </div>
                                                </div>
                                             </div>
                                 </div>
                                 <div class="nk-block-head-content">
                                    <div class="toggle-wrap nk-block-tools-toggle">
                                       <a href="#" class="btn btn-icon btn-trigger toggle-expand mr-n1" data-target="pageMenu"><em class="icon ni ni-menu-alt-r"></em></a>
                                       <div class="toggle-expand-content" data-content="pageMenu">
                                          <ul class="nk-block-tools g-3">
                                             <li><button onclick="exportTableToExcel('dataTables', 'student Report.xlsx')" class="btn btn-primary"><em class="icon ni ni-download-cloud"></em><span>Export</span></button></li>
                                             <li>
                                                <div class="path">
                                                   <div class="path-item"><a href="index.php" style="color:black;">Home</a> /</div>
                                                   <div class="path-item">Student List</div>
                                                </div>
                                             </li>
                                          </ul>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <hr />
                           </div>
                           <div class="nk-block">
                              <div class="card card-bordered card-full" style="background: #c1c1c133;">
                                 <div class="card-inner">
                                    <div class="row">
                                       <div class="col-md-6 col-xl-3" style="margin-top:10px;">
                                          <div class="card card-bordered" id="tooltip-container3" style="box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 8);">
                                             <div class="card-body" style="text-align: center;">
                                                <h5 class="mt-0 font-16">Total Student</h5>
                                                <h6 class="text-primary my-3" style="font-size: 35px;">
												<?php
												$sql = "SELECT COUNT(*) AS total FROM $tableName";
												$result = mysqli_query($connection,$sql) or die(mysqli_error());

													// Check if query was successful
													if ($result) {
														// Fetch the count
														$row = $result->fetch_assoc();
														$count = $row['total'];
														//echo "Total records: " . $count;
													} else {
														echo "Error: " . $conn->error;
													}
												?>
                                                   <span data-plugin="counterup"><?php echo $count?></span>
                                                </h6>
                                                </span></h6>
                                                
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                              <div class="card card-bordered card-full" style="background: #c1c1c133;">
                                 <div class="card-inner">
                                    <!--<div id="tblCustomers" style="text-align: center;">-->
                                    <div class="table-responsive" id="tblCustomers" style="text-align: center;">
                                       <table id="dataTables" class="table nk-tb-list is-separate is-medium mb-3" style="margin-top: 20px; margin-bottom: 20px;">
    <thead>
        <tr class="nk-tb-item nk-tb-head" style="font-size: 12px; font-weight: 700;">
            <th class="nk-tb-col ">Id</th>
            <th class="nk-tb-col ">Student</th>
            <th class="nk-tb-col ">Subject</th>
            <th class="nk-tb-col ">Marks</th>
            <th class="nk-tb-col ">Action</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $query = "SELECT * FROM $tableName";
        $result = mysqli_query($connection, $query) or die(mysqli_error($connection));

        while ($row = mysqli_fetch_array($result)) {
            $id = $row['id'];
            $username = $row['name'];
            $subject = $row['subject'];
            $marks = $row['marks'];
        ?>
            <tr class="odd gradeX nk-tb-item" style="font-size: 12px; font-weight: 700;">
                <td class="nk-tb-col text-success"><?php echo $id; ?></td>
                <td class="nk-tb-col "><?php echo $username; ?></td>
                <td class="nk-tb-col "><?php echo $subject; ?></td>
                <td class="nk-tb-col "><?php echo $marks; ?></td>
                <td class="nk-tb-col" style="width:200px;">
                    <a style="background: #ffa353; color: #fff; width: 35px; font-size: 15px; padding: 6px; border: 2px solid #ffa353; border-radius: 9px;" href="#" data-toggle="modal" data-target="#edit-<?php echo $id; ?>"><em class="icon ni ni-edit"></em>Edit</a>
                    <a style="background: red; color: #fff; width: 35px; font-size: 15px; padding: 6px; border: 2px solid #ffa353; border-radius: 9px;" href="#" data-toggle="modal" data-target="#delete-<?php echo $id; ?>"><em class="icon ni ni-trash"></em>Delete</a>
				</td>
            </tr>
			

            <!-- Edit Modal -->
            <div class="modal fade" id="edit-<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="editModalLabel-<?php echo $id; ?>" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editModalLabel-<?php echo $id; ?>">Update Student Details</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form autocomplete="off" action="update_student.php" method="post" enctype="multipart/form-data" role="form" class="form-validate is-alter">
                                <div class="col-md-12 form-group">
								<input type="hidden" class="form-control" value="<?php echo $id; ?>" name="id" required>
                                <div class="form-group">
                                    <label class="form-label" for="username-<?php echo $id; ?>">Username</label>
                                    <input type="text" class="form-control" id="username-<?php echo $id; ?>" name="username" value="<?php echo $username; ?>" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="subject-<?php echo $id; ?>">Subject</label>
                                    <input type="text" class="form-control" id="subject-<?php echo $id; ?>" name="subject" value="<?php echo $subject; ?>" required>
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="marks-<?php echo $id; ?>">Marks</label>
                                    <input type="number" class="form-control" id="marks-<?php echo $id; ?>" name="marks" value="<?php echo $marks; ?>" required>
                                </div>
                                <div class="form-group">
                                    <button type="submit" name="update" class="btn btn-primary btn-md btn-block" style="width:150px"><em class="icon ni ni-plus"></em> Update</button>
                                </div>
							</div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
			
			<div class="modal fade" id="delete-<?php echo $id; ?>" tabindex="-1" role="dialog" aria-labelledby="editModalLabel-<?php echo $id; ?>" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel">Confirm Delete</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Are you sure you want to delete this item?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <a id="confirmDelete" href="index.php?delids=<?php echo $id; ?>" class="btn btn-danger">Delete</a>
            </div>
        </div>
                </div>
            </div>
			
			
        <?php } ?>
    </tbody>
</table>

                                    </div>
                                 </div>
                              </div>
                           </div>
                           <!-- .nk-block -->
                        </div>
                     </div>
                  </div>
               </div>
               <!-- content @e -->
               <!-- footer @s -->
               <script>
                  function exportTableToExcel(tableID, filename = '') {
                      const tableSelect = document.getElementById(tableID);
                      const workbook = XLSX.utils.table_to_book(tableSelect, { sheet: "Sheet1" });
                      XLSX.writeFile(workbook, filename || 'excel_data.xlsx');
                  }
               </script>
               <?php include('footer.php');?>
            </div>
         </div>
      </div>
   </body>
</html>