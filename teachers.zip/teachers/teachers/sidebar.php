<div class="nk-sidebar nk-sidebar-fixed is-dark " data-content="sidebarMenu">
                <div class="nk-sidebar-element nk-sidebar-head">
                    <div class="nk-menu-trigger">
                        <a href="#" class="nk-nav-toggle nk-quick-nav-icon d-xl-none" data-target="sidebarMenu"><em class="icon ni ni-arrow-left"></em></a>
                        <a href="#" class="nk-nav-compact nk-quick-nav-icon d-none d-xl-inline-flex" data-target="sidebarMenu"><em class="icon ni ni-menu"></em></a>
                    </div>
                    <div class="nk-sidebar-brand">
                        <a href="index.php" class="logo-link nk-sidebar-logo">
                            <img class="logo-light logo-img-lg" src="assets/images/logo.jpg">
                            <img class="logo-dark logo-img-lg" src="assets/images/logo.jpg">
                        </a>
                    </div>
                </div><!-- .nk-sidebar-element -->
                <div class="nk-sidebar-element nk-sidebar-body">
                    <div class="nk-sidebar-content">
                        <div class="nk-sidebar-menu" data-simplebar>
                            <ul class="nk-menu">
                                
                                <li class="nk-menu-heading">
                                    <h6 class="overline-title text-primary-alt">Navigations</h6>

                                  </li><!-- .nk-menu-heading -->
                                
                                   
                                
                              
                                
                              <li class="nk-menu-item has-sub">
                                    <a href="#" class="nk-menu-link nk-menu-toggle">
                                        <span class="nk-menu-icon"><em class="icon ni ni-property"></em></span>
                                        <span class="nk-menu-text">Sap CRM Leads</span>
                                    </a>
                                    <ul class="nk-menu-sub">
                                       
                                        <li class="nk-menu-item">
                                            <a href="enter_leads.php" class="nk-menu-link"><span class="nk-menu-text">Enter Leads</span></a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="sap_crm_leads.php" class="nk-menu-link"><span class="nk-menu-text">Open Leads</span></a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="sap_crm_wonleads.php" class="nk-menu-link"><span class="nk-menu-text">Won Leads</span></a>
                                        </li>
                                        <li class="nk-menu-item">
                                            <a href="sap_crm_lostleads.php" class="nk-menu-link"><span class="nk-menu-text">Los Leads</span></a>
                                        </li>
                                        
                                    </ul>
                                </li>
                               

                                </ul>   
                                
                                
                                    <!-- .nk-menu-sub -->
                                <!-- .nk-menu-item -->
                                
                        </div><!-- .nk-sidebar-menu -->
                    </div><!-- .nk-sidebar-content -->
                </div><!-- .nk-sidebar-element -->
            </div>