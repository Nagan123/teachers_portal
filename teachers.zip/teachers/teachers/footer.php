<div class="nk-footer">
   
                    <div class="container-fluid">
                        <div class="nk-footer-wrap">
                             <div class="nk-footer-copyright"> &copy; 2024 <a href="https://naganagouda.netlify.app/" target="_blank">Naganagouda</a>
                            </div>
                            <div class="nk-footer-links">
                                <ul class="nav nav-sm">
                                    <li class="nav-item"><a class="nav-link" href="#">Terms</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#">Privacy</a></li>
                                    <li class="nav-item"><a class="nav-link" href="#">Help</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- footer @e -->
            </div>
            <!-- wrap @e -->
        </div>
        <!-- main @e -->
    </div>
    <!-- app-root @e -->
    <!-- JavaScript -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="assets/js/bundle.js?ver=2.4.0"></script>
    <script src="assets/js/scripts.js?ver=2.4.0"></script>
    <script src="assets/js/charts/gd-default.js?ver=2.4.0"></script>
	
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.22/pdfmake.min.js"></script>
    <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/html2canvas/0.4.1/html2canvas.min.js"></script>
   
    
	
	<script src="assets/plugins/plugins/dataTables/jquery.dataTables.js"></script>
    <script src="assets/plugins/plugins/dataTables/dataTables.bootstrap.js"></script>

        <!-- Custom Theme JavaScript -->
         <!-- <script src="js/sb-admin-2.js"></script>-->

        <script>
            $(document).ready(function() {
                $('#dataTables').dataTable();
            });
        </script>
        
       
  

		
</body>

</html>