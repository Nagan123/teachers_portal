<?php
  
	$connection =mysqli_connect('localhost', 'root', '', 'teacher_portal');
	
		if(!$connection) 
	{
	    die("Unable to connect to the database".mysqli_error($connection));
	}
	  
?>